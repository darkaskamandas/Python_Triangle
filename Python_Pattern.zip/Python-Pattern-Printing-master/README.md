# Python Pattern 

This repository consists of all the pattern related python programs . It can be square, rectangle, triangle, L shape pattern etc
