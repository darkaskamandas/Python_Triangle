def squarePattern(n):
  for i in range(n):
    print "*" * n
  
      
print squarePattern(5)

"""
output

*****
*****
*****
*****
*****


"""
