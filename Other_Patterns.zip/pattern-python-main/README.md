# Pattern Printing 

<!-- Used Emojis: 🎖️ -->

## Patterns with the Video Tutorial

#### [⭐ Check the full playlist](https://www.youtube.com/playlist?list=PL7ZCWbO2Dbl5n9oOiG0V3ZXzt-6W1pOnH)

### 🎖️ Pattern 1

```
*
* *
* * *
* * * *
* * * * *
```
[Check the Video tutorial](https://youtu.be/apq1sHtj9Fk)

### 🎖️ Pattern 2

```
* * * * *
* * * * *
* * * * *
* * * * *
* * * * *
```
[Check the Video tutorial]()

### 🎖️ Pattern 2 - Understanding the `range` function

[Check the Video tutorial]()

### 🎖️ Pattern 3

```
1  
1  2  
1  2  3  
1  2  3  4  
1  2  3  4  5
```

[Check the Video tutorial]()

### 🎖️ Pattern 4

```
1  
2  2
3  3  3
4  4  4  4
5  5  5  5  5
```

[Check the Video tutorial]()

### 🎖️ Pattern 5
```
🎖️ 
🎖️  🎖️ 
🎖️  🎖️  🎖️ 
🎖️  🎖️  🎖️  🎖️ 
🎖️  🎖️  🎖️  🎖️  🎖️ 
```
or
```
# 
# #
# # #
# # # #
# # # # #
```
[Check the Video tutorial]()

### 🎖️ Pattern 6
```
1 1 1 1 1 
2 2 2 2 
3 3 3 
4 4 
5 
```
[Check the Video tutorial]()

### 🎖️ Pattern 7
```
5 5 5 5 5 
5 5 5 5 
5 5 5 
5 5 
5 
```
[Check the Video tutorial]()


### 🎖️ Pattern 8
```
1 
2 1 
3 2 1 
4 3 2 1 
5 4 3 2 1
```

[Check the Video tutorial](https://youtu.be/0nqenoaIq8s)
