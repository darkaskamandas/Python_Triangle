for i in range(1 , 15, 2): # ending value: up to 5
    print(i)
