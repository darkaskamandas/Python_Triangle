n = int(input('Enter the number of rows: '))
for row in range(n):
    for col in range(n):
        print('* ' , end = "")
    print()