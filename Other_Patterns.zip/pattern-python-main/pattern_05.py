n = int(input('Enter the value for n: '))
for row in range(1, n+1):
    for col in range(1, row+1):
        print("# ", end='')
    print()


# For printing 🎖️ emojis

# n = int(input('Enter the value for n: '))
# for row in range(1, n+1):
#     for col in range(1, row+1):
#         print("🎖️ ", end='')
#     print()
